// Configure your AirGate in this file.

// Set your callsign-SID:
#define CALLSIGN "WA5ZNU-2"

// Set your APRS passcode code:
// Contact local APRS hams to find out your passcode, or ask on the book forum site.
#define PASSCODE "99999"

// Define the latitude and longitude of your AirGate:
#define LATITUDE "3725.73N"
#define LONGITUDE "12206.90W"

// PHG gives information about the station capabilities.  
// PHG01000 describes an RX-only beacon 20ft AGL with a 0db gain "discone" antenna.
// PHG01600 is the same with a 6dB gain (J-Pole) antenna
// PGO02600 is the J-Pole up 30ft.
// Calculate yours at http://www.aprsfl.net/phgr.php 
#define PHG "PHG01000"

// IP address of the APRS-IS backbone gateway in your country:
IPAddress aprsgate(198, 137, 202, 21);    //sjc.aprs2.net 

// Enter the MAC address Arduino Ethernet:
// Find it on the board or the box it came in.
byte mac[] = { 0x90, 0xA2, 0xDA, 0x00, 0x75, 0xCA };

// If use you DHCP, define this:
#define USE_DHCP 1
 // Otherwise, comment it out and instead specify your IP address, gateway, and subnet manually:
// IPAddress ip(192, 168, 178, 177);
// byte gateway[] = { 192, 168, 178, 1 };
// byte subnet[] = { 255, 255, 255, 0 };

// TCP port of APRS-IS service:
int aprsport = 14580;

// Software version information, for login and position packet.
#define VERSION "Arduino_AirGate_TCP (dl8rds,2012-05-30)"
#define INFO "Arduino AirGate IGATE"

// APRS destination, which indicates the APRS device being used:
// This one identifies Argent Data products.
#define DESTINATION "APOTW1"
