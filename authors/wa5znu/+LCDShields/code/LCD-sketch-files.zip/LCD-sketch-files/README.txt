These sketch files are public domain.
Leigh L. Klotz, Jr. WA5ZNU
