Original from user fj604 at http://www.dfrobot.com/forum/index.php?topic=31.0

Unzip this folder to:
sketchbook\libraries , then restart Arduino.

Extends the LiquidCrystal library.

Updates from WA5ZNU: 
 - backlight-changes.txt
 - debounce-changes.txt
