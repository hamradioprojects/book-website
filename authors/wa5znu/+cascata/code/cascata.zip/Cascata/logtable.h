#ifndef LOGTABLE_H
#define LOGTABLE_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

uint8_t db(int x);

#ifdef __cplusplus
}
#endif

#endif
